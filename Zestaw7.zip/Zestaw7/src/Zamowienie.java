public class Zamowienie {
    KoszykZakupowy koszyk;
    private String statusZamowienia;



    public Zamowienie(KoszykZakupowy koszyk, String statusZamowienia) {
        this.koszyk = koszyk;
        this.statusZamowienia = statusZamowienia;
    }

    public void ustawStatusZamowienia(String nowyStatus){
        this.statusZamowienia = nowyStatus;
    }

    public void wyswietlZamowienie(){
        System.out.println("Zamówienie: ");
        koszyk.WyswietlZawartoscKoszyka();
        System.out.println("Status zamówienia: " + statusZamowienia);
    }

}
