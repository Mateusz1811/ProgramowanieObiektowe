public class Main {
    public static void main(String[] args) {
        Adres adres = new Adres("Grunwaldzka", "5", "Rybno", "13220");
        adres.pokaz();

        Adres adres2 = new Adres("Grunwaldzka", "6", "Działdowo","13200");

        System.out.println(Adres.przed(adres2,adres));

        System.out.println(adres.getClasss());

    }


    public String getClasss() {return "Cześć jestem klasą " + this.getClass().getSimpleName();}

}