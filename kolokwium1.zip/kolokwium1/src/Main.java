public class Main {


    public static void ciagArytmetycznyRodzajuM(int n, int m, int a1, int[] r) {
        int[] ciag = new int[n];
        ciag[0] = a1;
        if(m==1){
            for(int i=1;i<n;i++){
                ciag[i] = a1 + r[0];
            }
        }
        if(m==2){
            for(int i=1;i<n;i++){
                ciag[i] = a1 + (n-1)*r[0] + ((n-1)*(n-1)) * r[1];
            }
        }
        if(m==3){
            for(int i=1;i<n;i++){
                ciag[i] = a1 + (n-1)*r[0] + ((n-1)*(n-1)) * (r[1]) + ((n-1)*(n-1)*(n-1)) * r[2];
            }

        }
    }


    public static boolean czyCiagArytmetyczny(int[] tab){
        int r = tab[1] - tab[0];
        int count = 1;
        int dlugoscTablicy = tab.length;
        for(int i=0; i<dlugoscTablicy-1; i++){
            if((tab[i+1]-tab[i])==r){
                count++;

            }

        }
        return count==dlugoscTablicy;
    }

    public static boolean czyCiagArytmetyczny3rodzaju(int[] tab) {
        int[] tab2 = new int[tab.length];
        int r2 = tab2[1] - tab2[0];
        int count = 1;
        int dlugoscTablicy = tab.length;
        for (int i = 0; i < dlugoscTablicy - 1; i++) {
            tab2[i] = tab[i + 1] - tab[i];
        }
        for (int i = 0; i < dlugoscTablicy - 1; i++) {
            if ((tab2[i + 1] - tab2[i]) == r2) {
                count++;
            }
        }
        return count==dlugoscTablicy;
    }


    public static boolean czyCiagArytmetycznyRodzajuM(int[] tab, int m){
        if(m==1 && czyCiagArytmetyczny(tab)==true){
            return true;
        }
        if(m==2 && czyCiagArytmetyczny(tab)==true){
            return true;
        }
        if(m==3 && czyCiagArytmetyczny3rodzaju(tab)==true){
            return true;
        }
        return false;

    }

    public static int podciag(int[] tab){
        int zmienna = 0;
        int dlugosc = 0;
        for(int i=0;i<tab.length-1;i++){
            if(tab[i]>tab[i+1]){
                zmienna+=1;
                if(dlugosc<zmienna){
                    dlugosc=zmienna;
                }
                zmienna=0;
            }
        }
        return dlugosc;
    }





    public static void sekwencjaCollatza(int n, int c) {
        int[] tab = new int[n];
        for (int i = 0; i < n; i++) {
            if (c % 2 == 0) {
                tab[i] = c / 2;
                c++;
            }
            else{
                tab[i] = c * 3 + 1;
                c++;
            }
        }
        for(int i=0;i<tab.length;i++){
            System.out.print(tab[i]+" ");
        }
    }

    public static void minMaxSekwencjaCollatza(int n, int c){
        int[] tab = new int[n];
        for (int i = 0; i < n; i++) {
            if (c % 2 == 0) {
                tab[i] = c / 2;
                c++;
            }
            else{
                tab[i] = c * 3 + 1;
                c++;
            }
        }
        int min = tab[0];
        int max = tab[0];
        for(int i=0;i<n;i++){
            if(tab[i]<min){
                min = tab[i];
            }
            else if(tab[i]>max){
                max = tab[i];
            }

        }
        System.out.print("min=" + min + " max=" + max);

    }


    public static void main(String[] args) {
        int[] ciag = {2,5,4,9,2,13,15};
        int[] ciag2rodzaju = {1,4,9,16};
        int[] ciag3rodzaju = {1,8,27,64,125};
        System.out.println(czyCiagArytmetyczny(ciag));
        System.out.println(czyCiagArytmetyczny(ciag2rodzaju));
        System.out.println(czyCiagArytmetyczny3rodzaju(ciag3rodzaju));
        System.out.println(podciag(ciag));
        int n = 10;
        int c = 2;
        sekwencjaCollatza(n,c);
        minMaxSekwencjaCollatza(n,c);

    }
}