import java.util.Collection;
import java.util.*;

public class Main {

    public static <T> void printUnique(Collection<T> items) {
        Set<T> uniqueElements = new HashSet<>(items);

        for(T item : uniqueElements){
            System.out.println(item);
        }
    }

    public <T> ArrayList<T> mergeLists(ArrayList<T> first, ArrayList<T> second){
        ArrayList<T> mergedList = new ArrayList<>();
        mergedList.addAll(first);
        mergedList.addAll(second);

        return mergedList;
    }

    public static <T extends Comparable<T>> TreeSet<T> findElementsInRange(TreeSet<T> set, T lowerBound, T upperBound){
        return new TreeSet<>(set.subSet(lowerBound,true, upperBound, true));
    }

    public static <T> boolean isPalindrome(LinkedList<T> list){
        LinkedList<T> pierwszaPolowa = new LinkedList<>();
        LinkedList<T> drugaPolowa = new LinkedList<>();

        int size = list.size();
        int srodek = size / 2;

        for(int i =0; i< srodek;i++){
            pierwszaPolowa.add(list.get(i));
        }

        for(int i = size -1;i>=srodek;i--){
            drugaPolowa.add(list.get(i));
        }

        while(!pierwszaPolowa.isEmpty()){
            if(!pierwszaPolowa.poll().equals(drugaPolowa.poll())){
                return false;
            }
        }
        return true;
    }

    public static <T> HashSet<T> findUniqueElements(List<T> list){
        return new HashSet<>(list);
    }

    public static <K, V> HashMap<V, Integer> countValueOccurences(HashMap<K, V>map){
        HashMap<V, Integer> valueCountMap = new HashMap<>();

        for(V value : map.values()){
            valueCountMap.put(value, valueCountMap.getOrDefault(value, 0) + 1);
        }
        return valueCountMap;

    }

    public static<K extends Comparable<K>, V> TreeMap<K, V> subMapInRange(TreeMap<K, V> map, K startKey, K endKey){
        return new TreeMap<>(map.subMap(startKey, true, endKey, true));
    }



    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(1);
        list.add(2);

        printUnique(list);

        ArrayList<String> list2 = new ArrayList<>();
        list2.add("a");
        list2.add("b");
        list2.add("b");

        printUnique(list2);

        ArrayList<Integer> list3 = new ArrayList<>();
        list3.add(5);
        list3.add(6);
        list3.add(7);
        list3.add(8);


        TreeSet<Integer> set = new TreeSet<>();
        set.add(1);
        set.add(3);
        set.add(5);
        set.add(7);
        set.add(9);

        TreeSet<Integer> wynik = findElementsInRange(set, 3, 7);

        System.out.println(wynik);

        System.out.println(findUniqueElements(list));


    }
}