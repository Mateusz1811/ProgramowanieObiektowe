public record Address(String street, int houseNumber, int postalCode, String city) {
}
