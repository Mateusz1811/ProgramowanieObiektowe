public record BookDT0(String title, String author, int price, int yearOfPublication) {
    public String informacje(){
        return "Tytuł: " + title + ", author: " + author + ", price: " + price + ", year: " + yearOfPublication;
    }
}
