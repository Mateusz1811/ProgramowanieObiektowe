public class Main {
    public static void main(String[] args) {
       BookDT0 ksiazka1 = new BookDT0("Tatuażyk", "Sebastian Enrique Alvarez", 100, 2023);
       BookDT0 ksiazka2 = new BookDT0("dsadas", "dsadsa", 69, 420);

       System.out.println(ksiazka1.informacje());
       System.out.println(ksiazka2.informacje());

       Address addressAndrewPlomba = new Address("Grunwaldzka", 5, 13220, "Rybno");
       Person person = new Person("Andrew", "Plomba", addressAndrewPlomba);

       System.out.println(person.firstName() + " " + person.lastName() + " " + person.address());

       Car Skoda = new Car("Skoda", "Octavia", 7.2);
       double kosztPodrozy = Skoda.fuelCost(6.80,153.5);
       System.out.println("Koszt podrozy dla: " + Skoda.brand() + " " + Skoda.model() + ", wynosi: " + kosztPodrozy);

       PersonZad9 osoba = new PersonZad9("Andrzej", 18);
       PersonZad9 osoba2 = new PersonZad9("Antoni", -24);

       System.out.println(osoba.imie() + " " + osoba.wiek());
       System.out.println(osoba2.imie() + " " + osoba2.wiek());

       BankAccount konto1 = new BankAccount("123456");
       BankAccount konto2 = new BankAccount("987654321");

       System.out.println(konto1.numerKonta() + " " + konto1.saldo());
       System.out.println(konto2.numerKonta() + " " + konto2.saldo());


       System.out.println("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||");

       Book book = new Book("The Hobbit", "J.R.R Tolkien");
       book.addReview(4.5);
       book.addReview(5.0);
       book.removeReview(4.5);
       System.out.println(book);

       FantasyBook fantasyBook = new FantasyBook("The Hobbit", "J.R.R Tolkien", "High Fantasy");
       fantasyBook.addReview(4.8);
       fantasyBook.addReview(4.9);
       System.out.println(fantasyBook);

       FantasyBook anotherFantasyBook = new FantasyBook("The Hobbit", "J.R.R Tolkien", "High Fantasy");
       System.out.println("Czy ksiazki sa rowne? " + fantasyBook.equals(anotherFantasyBook));

    }


}