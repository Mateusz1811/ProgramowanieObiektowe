import java.util.Arrays;
import java.util.Objects;


public class Book {
    private String title;
    private String author;
    private double[] reviews;
    private int reviewCount;

    public Book(String title, String author){
        this.title = title;
        this.author = author;
        reviews = new double[10];
        this.reviewCount = 0;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public double[] getReviews() {
        return Arrays.copyOf(reviews, reviewCount);
    }

    public void addReview(double review) {
        if(reviewCount == reviews.length){
            reviews = Arrays.copyOf(reviews, reviews.length * 2);
        }
        reviews[reviewCount++] = review;
    }

    public void removeReview(double review) {
        for(int i =0; i<reviewCount; i++){
            if(reviews[i] == review){
                for(int j=0;j<reviewCount-1;j++){
                    reviews[j] = reviews[j+1];
                }
                reviewCount--;
                return;
            }
        }
    }


    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + '\'' +
                ", author='" + author +'\'' +
                ", reviews=" + Arrays.toString(getReviews()) +
                '}';
    }

    @Override
    public boolean equals(Object o){
        if(this == o) return true;
        if(o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return Objects.equals(title, book.title) &&
                Objects.equals(author, book.author) &&
                Arrays.equals(getReviews(), book.getReviews());
    }

    @Override
    public int hashCode(){
        int result = Objects.hash(title, author);
        result = 31 * result + Arrays.hashCode(getReviews());
        return result;
    }
}
