public record PersonZad9(String imie, int wiek) {
    public PersonZad9 {
        if(wiek<0){
            wiek = 0;
        }
    }
}
