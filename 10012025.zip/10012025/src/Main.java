import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

class zad28{
    class Pair<T>{
        private T first;
        private T second;

        Pair(T first, T second) {
            this.first = first;
            this.second = second;
        }

        public T getFirst() {
            return first;
        }

        public void setFirst(T first) {
            this.first = first;
        }

        public T getSecond() {
            return second;
        }

        public void setSecond(T second) {
            this.second = second;
        }

        @Override
        public String toString() {
            return "Pair [first=" + first + ", second=" + second + "]";
        }
    }



    class Animal2{
        private String name;

        public Animal2(String name){
            this.name = name;
        }

        public String getName(){
            return name;
        }

        @Override
        public String toString() {
            return name;
        }

    }

    class Dog2 extends Animal2{
        private int age;
        public Dog2(String name, int age){
            super(name);
            this.age = age;
        }

        public int getAge(){
            return age;
        }

        public String toString(){
            return "imie: " + getName() + ", wiek: " + age;
        }

    }

}





class Animal{
    private String name;
    private int age;

    public Animal(String name, int age){
        this.name = name;
        this.age = age;
    }

    public int getAge(){
        return age;
    }

    @Override
    public String toString(){
        return "Imię: " + name + ", wiek: " + age;
    }

}

class Dog extends Animal{
    public Dog(String name ,int age){
        super(name, age);
    }
}








class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return name + " (" + age + ")";
    }
}




class Box<T>{
    T obiekt;

    public void setObiekt(T obiekt){
        this.obiekt = obiekt;
    }

    public T getObiekt(){
        return obiekt;
    }


}

class Counter<T>{
    List<T> lista =  new ArrayList<T>();

    public void add(T obiekt){
        lista.add(obiekt);
    }

    public int getCount(){
        return lista.size();
    }
}


public class Main{
    public static <T> boolean isEquala(T a, T b){
        return a.equals(b);
    }


    public static <T> void reverseArray(T[] array){
        if(array == null){
            throw new IllegalArgumentException("Tablica nie moze byc null");
        }

        int dlugosc = array.length;
        for(int i=0;i<dlugosc/2;i++){
            T temp = array[i];
            array[i] = array[dlugosc-1-i];
            array[dlugosc-1-i] = temp;
        }
    }


    public static<T> void swap(T[] array, int index1, int index2){
        if(array == null){
            throw new IllegalArgumentException("Tablica nie moze byc null");
        }

        if(index1<0 || index1>=array.length || index2<0 || index2>=array.length){
            throw new IllegalArgumentException("Index spoza zakresu tablicy");
        }

        T temp = array[index1];
        array[index1] = array[index2];
        array[index2] = temp;
    }


    public static <T extends Animal> T findMax(T element1, T element2){
        if(element1 == null || element2 == null){
            throw new IllegalArgumentException("Obiekty nie moga byc rowne null");
        }

        return element1.getAge() > element2.getAge() ? element1 : element2;


    }


    public static class Pair<T>{
        private T first;
        private T second;

        Pair(T first, T second) {
            this.first = first;
            this.second = second;
        }

        public T getFirst() {
            return first;
        }

        public void setFirst(T first) {
            this.first = first;
        }

        public T getSecond() {
            return second;
        }

        public void setSecond(T second) {
            this.second = second;
        }

        @Override
        public String toString() {
            return "Pair [first=" + first + ", second=" + second + "]";
        }
    }



    public static class Animal2{
        private String name;

        public Animal2(String name){
            this.name = name;
        }

        public String getName(){
            return name;
        }

        @Override
        public String toString() {
            return name;
        }

    }

    public static class Dog2 extends Animal2 {
        private int age;
        public Dog2(String name, int age){
            super(name);
            this.age = age;
        }

        public int getAge(){
            return age;
        }

        public String toString(){
            return "imie: " + getName() + ", wiek: " + age;
        }

    }


    public static void findMinMaxAge(Dog2[] dogs, Pair<?super Dog2> result){
        if(dogs == null || dogs.length == 0){
            throw new IllegalArgumentException("tablica nie moze byc rowna null");
        }

        Dog2 minDog = dogs[0];
        Dog2 maxDog = dogs[0];

        for(Dog2 dog : dogs){
            if(dog.getAge() < minDog.getAge()){
                minDog = dog;
            }
            if(dog.getAge() > maxDog.getAge()){
                maxDog = dog;
            }
        }

        result.setFirst(minDog);
        result.setSecond(maxDog);
    }



    public static void main(String[] args){
        Box<String> b1 = new Box<>();
        b1.setObiekt("12357");
        System.out.println(b1.getObiekt());

        Box<Integer> b2 = new Box<>();
        b2.setObiekt(12357);
        System.out.println(b2.getObiekt());



        System.out.println(isEquala(b1.getObiekt(), b2.getObiekt()));
        System.out.println(isEquala("Ala", "Ala"));


        Character[] tablicaChar = {'A', 'B', 'C', 'D'};
        System.out.println("Tablice przed odwroceniem: " + Arrays.toString(tablicaChar));
        reverseArray(tablicaChar);
        System.out.println("Tablica po odwroceniu: " + Arrays.toString(tablicaChar));

        Boolean[] tablicaBool = {true, false, true, false};
        System.out.println("Tablica przed odwroceniem: " + Arrays.toString(tablicaBool));
        reverseArray(tablicaBool);
        System.out.println("Tablica po odwroceniu: " + Arrays.toString(tablicaBool));


        Person[] tablicaPerson = {
                new Person("Alice", 2),
                new Person("Bob", 3),
                new Person("Carol", 4),
        };

        System.out.println("Tablica przed odwroceniem: " + Arrays.toString(tablicaPerson));
        reverseArray(tablicaPerson);
        System.out.println("Tablica po odwroceniu: " + Arrays.toString(tablicaPerson));


        Integer[] tablicaInt = {1,2,3,4,5};
        System.out.println("Tablica przed odwroceniem: " + Arrays.toString(tablicaInt));
        swap(tablicaInt,0,2);
        System.out.println("Tablica po odwroceniu: " + Arrays.toString(tablicaInt));

        String[] tablicaString = {"Ala", "ma", "kota", "i", "psa"};
        System.out.println("Tablica przed odwroceniem: " + Arrays.toString(tablicaString));
        swap(tablicaString,0,2);
        System.out.println("Tablica po odwroceniu: " + Arrays.toString(tablicaString));

        System.out.println("Tablica przed odwroceniem: " + Arrays.toString(tablicaPerson));
        swap(tablicaPerson,0,2);
        System.out.println("Tablica po odwroceniu: " + Arrays.toString(tablicaPerson));


        Animal animal1 = new Animal("Słoń", 10);
        Animal animal2 = new Animal("Tygrys", 7);

        Animal starszyAnimal = findMax(animal1, animal2);
        System.out.println("Starsze zwierze: " + starszyAnimal);

        Dog dog1 = new Dog("Maksi", 5);
        Dog dog2 = new Dog("Luna", 6);

        Animal starszyDog = findMax(dog1, dog2);
        System.out.println("Starsze zwierze: " + starszyDog);

        Animal starszyMix = findMax(dog1, animal1);
        System.out.println("Starsze zwierze: " + starszyMix);


        Dog2[] dogs = {
                new Dog2("Maksi", 10),
                new Dog2("Luna", 8),
                new Dog2("Molly", 5),
                new Dog2("Nela", 3),
                new Dog2("Bella", 8)
        };

        Pair<Animal2> result = new Pair<>();

        findMinMaxAge(dogs,result);

        System.out.println("Najmlodszy pies" + result.getFirst());
        System.out.println("Najstarszy pies" + result.getSecond());



    }
}