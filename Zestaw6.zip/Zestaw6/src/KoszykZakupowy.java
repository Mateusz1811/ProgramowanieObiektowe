import java.util.ArrayList;


public class KoszykZakupowy{
    private ArrayList<Produkt> produktyWKoszyku;
    private ArrayList<Integer> iloscProduktow;

    public KoszykZakupowy(){
        this.produktyWKoszyku = new ArrayList<>();
        this.iloscProduktow = new ArrayList<>();
    }


    public void dodajProdukt(Produkt produkt, int ilosc){
        if(produkt.Dostepny(ilosc)){
            int indeks = produktyWKoszyku.indexOf(produkt);
            if(indeks!=-1){
                iloscProduktow.set(indeks, iloscProduktow.get(indeks) + ilosc);
            }else{
                produktyWKoszyku.add(produkt);
                iloscProduktow.add(ilosc);
            }
            produkt.usunZMagazynu(ilosc);
        }
    }

    public void usunProdukt(Produkt produkt, int ilosc){
        int indeks = produktyWKoszyku.indexOf(produkt);
        if(indeks!=-1){
            int obecnaIlosc = iloscProduktow.get(indeks);
            if(obecnaIlosc>=ilosc){
                iloscProduktow.set(indeks, obecnaIlosc-ilosc);
                produkt.usunZMagazynu(ilosc);
            }
        }
    }




    public void WyswietlZawartoscKoszyka(){
        if(produktyWKoszyku.isEmpty()){
            System.out.println("Koszyk jest pusty");
        }else{
            System.out.println("Zawartosc koszyka: ");
            for(int i = 0; i < produktyWKoszyku.size(); i++){
                Produkt produkt = produktyWKoszyku.get(i);
                int ilosc = iloscProduktow.get(i);

                System.out.println("- " + produkt.getNazwa() + ": " + ilosc + " szt.");
            }
        }
    }


    public double obliczCalkowitaWartosc(){
        double suma = 0.0;
        for(int i = 0; i < produktyWKoszyku.size(); i++){
            Produkt produkt = produktyWKoszyku.get(i);
            int ilosc = iloscProduktow.get(i);
            suma += produkt.getCena() * ilosc;
        }
        return suma;
    }
}


