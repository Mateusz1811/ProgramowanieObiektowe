public class Main {
    public static void main(String[] args) {
        Produkt produkt = new Produkt("Coca Cola", 5.99, 34);
        produkt.wyswietlInformacje();
        produkt.dodajDoMagazynu(4);
        produkt.wyswietlInformacje();
        produkt.usunZMagazynu(10);
        produkt.wyswietlInformacje();
        produkt.usunZMagazynu(100);
        produkt.wyswietlInformacje();


        Produkt czekolada = new Produkt("Czekolada", 2.99, 30);
        Produkt jajka = new Produkt("Jajka", 9.99, 70);
        Produkt serek = new Produkt("Serek", 3.59, 80);
        Produkt sok = new Produkt("Sok", 3.99, 100);
        Produkt mleko = new Produkt("Mleko", 3.29, 50);
        Produkt KitKat = new Produkt("KitKat", 2.99, 60);


        KoszykZakupowy koszyk = new KoszykZakupowy();

        koszyk.dodajProdukt(czekolada, 5);
        koszyk.dodajProdukt(jajka, 10);
        koszyk.dodajProdukt(serek, 20);
        koszyk.dodajProdukt(produkt, 2);

        koszyk.WyswietlZawartoscKoszyka();
        double wartosc = koszyk.obliczCalkowitaWartosc();
        System.out.println("Calkowita wartosc koszyka: " + wartosc + " zł");


        Zamowienie zamowienie = new Zamowienie(koszyk, "Nowe");
        zamowienie.wyswietlZamowienie();
        zamowienie.ustawStatusZamowienia("W trakcie realizacji");
        zamowienie.wyswietlZamowienie();
        zamowienie.ustawStatusZamowienia("Zrealizowane");
        zamowienie.wyswietlZamowienie();

        KoszykZakupowy koszyk2 = new KoszykZakupowy();
        koszyk2.dodajProdukt(jajka, 1);
        koszyk2.dodajProdukt(serek, 2);
        koszyk2.dodajProdukt(produkt, 3);
        koszyk2.dodajProdukt(czekolada, 2);

        Zamowienie zamowienie2 = new Zamowienie(koszyk2, "Nowe");

        Klient klient = new Klient("Andrew","Plomba");
        klient.dodajZamowienie(zamowienie2);

        KoszykZakupowy koszyk3 = new KoszykZakupowy();
        koszyk3.dodajProdukt(sok, 2);
        koszyk3.dodajProdukt(mleko, 1);
        koszyk3.dodajProdukt(KitKat, 1);

        Zamowienie zamowienie3 = new Zamowienie(koszyk3, "Nowe");
        klient.dodajZamowienie(zamowienie3);

        klient.wyswietlHistorieZamowien();

        double LacznyKoszt = klient.ObliczLacznyKosztZamowien();
        System.out.println("Laczny koszt zamowien klienta wynosi: " + LacznyKoszt + " zł");


        Sklep sklep = new Sklep();
        sklep.dodajProdukt(czekolada);
        sklep.dodajProdukt(jajka);
        sklep.dodajProdukt(serek);
        sklep.dodajProdukt(produkt);
        sklep.dodajProdukt(sok);
        sklep.dodajProdukt(mleko);
        sklep.dodajProdukt(KitKat);

        sklep.WyswietlOferte();

        KoszykZakupowy koszykSklep = new KoszykZakupowy();

        sklep.zakupy(klient, "Czekolada", 5, koszykSklep);
        sklep.zakupy(klient, "Sok", 10, koszykSklep);

        koszykSklep.WyswietlZawartoscKoszyka();

        System.out.println();

        System.out.println(sklep.wyszukajProdukt("Czekolada"));

        Platnosc platnosc = new Platnosc(koszyk2.obliczCalkowitaWartosc());
        platnosc.zaplac();
        Zamowienie2 ZamowienieDoOstatniegoZad = new Zamowienie2(koszyk2, platnosc);
        ZamowienieDoOstatniegoZad.finalizujZamowienie();
        ZamowienieDoOstatniegoZad.wyswietlZamowienie();
        ZamowienieDoOstatniegoZad.zwrocProdukt(serek, 1);
        ZamowienieDoOstatniegoZad.wyswietlZamowienie();

    }
}
