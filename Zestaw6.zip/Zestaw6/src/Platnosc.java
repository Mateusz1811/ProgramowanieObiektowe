public class Platnosc {
    private double kwota;
    private String statusPlatnosci;

    public Platnosc(double kwota){
        this.kwota = 0;
        this.statusPlatnosci = "Nieopłacone";
    }

    public void zaplac(){
        this.statusPlatnosci = "Opłacone";
    }

    public String getStatusPlatnosci(){
        return this.statusPlatnosci;
    }

    public double getKwota(){
        return this.kwota;
    }

    public void ustawKwote(double kwota){
        this.kwota = kwota;
    }
}
