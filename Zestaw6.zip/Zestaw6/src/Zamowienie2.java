public class Zamowienie2 {
    private KoszykZakupowy koszyk;
    private Platnosc platnosc;
    private String statusZamowienia;

    public Zamowienie2(KoszykZakupowy koszyk, Platnosc platnosc) {
        this.koszyk = koszyk;
        this.platnosc = platnosc;
        statusZamowienia = "Nieopłacone";
    }

    public void finalizujZamowienie(){
        if(platnosc.getStatusPlatnosci().equals("Opłacone")){
            this.statusZamowienia = "Gotowe do wysyłki";
        }else{
            System.out.println("Zamowienie nie zostalo oplacone");
        }
    }

    public void zwrocProdukt(Produkt produkt, int ilosc){
        koszyk.usunProdukt(produkt, ilosc);
        produkt.dodajDoMagazynu(ilosc);
        double nowaKwota = koszyk.obliczCalkowitaWartosc();
        platnosc.ustawKwote(nowaKwota);
    }

    public void wyswietlZamowienie(){
        koszyk.WyswietlZawartoscKoszyka();
        System.out.println("Status zamówienia: " + statusZamowienia);
        System.out.println("Kwota do zapłaty: " + platnosc.getKwota() + " zł");
    }
}
