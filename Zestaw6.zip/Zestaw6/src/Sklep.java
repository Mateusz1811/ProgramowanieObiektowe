import java.util.ArrayList;


public class Sklep {
    private ArrayList<Produkt> produkty;

    public Sklep(){
        this.produkty = new ArrayList<>();
    }

    public void dodajProdukt(Produkt produkt){
        produkty.add(produkt);
    }

    public void WyswietlOferte(){
        if(produkty.isEmpty()){
            System.out.println("Oferta sklepu jest pusta.");
        }else{
            System.out.println("Oferta sklepu: ");
            for(Produkt produkt: produkty){
                produkt.wyswietlInformacje();
            }
        }
    }

    public Produkt wyszukajProdukt(String nazwa){
        for(Produkt produkt: produkty){
            if(produkt.getNazwa().equalsIgnoreCase(nazwa)){
                return produkt;
            }
        }
        return null;
    }

    public void zakupy(Klient klient, String nazwaProduktu, int ilosc, KoszykZakupowy koszyk){
        Produkt produkt = wyszukajProdukt(nazwaProduktu);
        if(produkt != null && produkt.Dostepny(ilosc)){
            koszyk.dodajProdukt(produkt, ilosc);
        }else{
            System.out.println("Produkt nie jest dostepny w podanej ilosci.");
        }
    }
}
