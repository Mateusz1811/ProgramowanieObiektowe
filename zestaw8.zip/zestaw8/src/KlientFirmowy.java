import java.util.ArrayList;

public class KlientFirmowy extends Klient{
    public final String NIP = "1234567895";
    public final String REGON = "123456784";

    public KlientFirmowy(String imie, String nazwisko, ArrayList<Zamowienie> listaZamowien){
        super(imie, nazwisko, listaZamowien);
    }

    public KlientFirmowy(String imie, String nazwisko, ArrayList<Zamowienie> listaZamowien, Adres adres){
        super(imie, nazwisko, listaZamowien, adres);
    }


}
