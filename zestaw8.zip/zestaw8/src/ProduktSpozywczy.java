public class ProduktSpozywczy extends Produkt{
    public ProduktSpozywczy(String nazwa, int cena, int iloscNaMagazynie){
        super(nazwa, cena, iloscNaMagazynie);
    }


}
