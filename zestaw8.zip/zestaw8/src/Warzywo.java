public abstract class Warzywo{
    public abstract void smak();
    public abstract void umyj();
    public abstract void zjedz();

}
