public abstract class Owoc{
    public abstract void smak();
    public abstract void umyj();
    public abstract void zjedz();
}
