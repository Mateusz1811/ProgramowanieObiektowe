public class ProduktPrzemyslowy extends Produkt{
    public ProduktPrzemyslowy(String nazwa, int cena, int iloscNaMagazynie){
        super(nazwa, cena, iloscNaMagazynie);
    }
}
