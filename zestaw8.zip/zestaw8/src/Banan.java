public class Banan extends Owoc{
    @Override
    public void smak(){
        System.out.println("Banan smak");
    }
    @Override
    public void umyj() {
        System.out.println("Banan umyj");
    }
    @Override
    public void zjedz() {
        System.out.println("Banan zjedz");
    }
}
