public class Marchew extends Warzywo{
    @Override
    public void smak(){
        System.out.println("Marchew smak");
    }
    @Override
    public void umyj(){
        System.out.println("Marchew umyj");
    }
    @Override
    public void zjedz(){
        System.out.println("Marchew zjedz");
    }
}
