import java.util.ArrayList;

public class KlientIndywidualny extends Klient{
    public final String PESEL = "12345678911";

    public KlientIndywidualny(String imie, String nazwisko, ArrayList<Zamowienie> listaZamowien){
        super(imie, nazwisko, listaZamowien);
    }

    public KlientIndywidualny(String imie, String nazwisko, ArrayList<Zamowienie> listaZamowien, Adres adres){
        super(imie, nazwisko, listaZamowien, adres);
    }
}
